from django.apps import AppConfig


class OrgConfig(AppConfig):
    name = 'org'
